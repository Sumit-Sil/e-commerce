import React, { useEffect } from "react";
import { useState } from "react";
import { endPoints } from "../../apiURL/apiUrl";
import { useNavigate, useParams } from "react-router-dom";
import axiosInstance from "../../axiosInstance/axiosInstance";

const EditProduct = () => {
  const { id } = useParams();
  const api = endPoints.products + "/" + id;
  console.log(api)
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [img, setImg] = useState([]);
  const getItem = () => {
    axiosInstance
      .get(api)
      .then((res) => setData(res.data))
      .catch((err) => console.log("error", err));
  };
  useEffect(() => {
    getItem();
  }, [setData]);
  const handleImage = (file) => {
    const fileReader = new FileReader();
    fileReader.readAsDataURL(file);
    fileReader.addEventListener("load", () => {
      setImg(fileReader.result);
    });
  };

  console.log(data);
  const {productName,company,price,description,image}=data
  return (
    <div>
      <div
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1629139033414-76f3c0eacf84?q=80&w=1528&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')",
          height: "100vh",
        }}
      >
        <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
          <h2 className="text-2xl font-bold mb-4">Create A Product</h2>
          <form className="space-y-4 text-start">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Product Name
              </label>
              <input
                type="text"
                value={productName}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Company
              </label>
              <input
                type="text"
                value={company}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Price
              </label>
              <input
                type="number"
                value={price}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
              value={description}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                rows="2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Image
              </label>
              <input
                type="file"
                // value={image}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                onChange={(e) => {
                  handleImage(e.target.files[0]);
                }}
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600"
            >
              Update
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditProduct;
