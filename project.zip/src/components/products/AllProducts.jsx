// import React, { useEffect, useState } from "react";
// import Button from "react-bootstrap/Button";
// import Modal from "react-bootstrap/Modal";
// import { endPoints } from "../../apiURL/apiUrl";
// import axiosInstance from "../../axiosInstance/axiosInstance";
// import { useNavigate } from "react-router-dom";
// import { Link } from "react-router-dom";

// const SkeletonCard = () => (
//   <div className="border rounded shadow p-4 animate-pulse">
//     <div className="bg-gray-300 h-32 mb-2"></div>
//     <div className="bg-gray-300 h-4 mb-2 w-3/4"></div>
//     <div className="bg-gray-300 h-4 w-1/4"></div>
//   </div>
// );

// const AllProducts = () => {
//   const all_api = endPoints.products;
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [showModal, setShowModal] = useState(false);
//   const [deleteProductId, setDeleteProductId] = useState(null);
//   const [deleting, setDeleting] = useState(false);

//   const getProducts = async () => {
//     try {
//       setLoading(true);
//       const res = await axiosInstance.get(all_api);
//       setProducts(res.data);
//     } catch (err) {
//       setError(err.message);
//     } finally {
//       setLoading(false);
//     }
//   };
//   const navigate = useNavigate();

//   useEffect(() => {
//     getProducts();
//   }, []);

//   const deleteItem = async (pro_id) => {
//     try {
//       await axiosInstance.delete(`${all_api}/${pro_id}`);
//     } catch (err) {
//       console.error("Error deleting the product:", err);
//       throw err;
//     }
//   };

//   const handleDeleteClick = (pro_id) => {
//     setDeleteProductId(pro_id);
//     setShowModal(true);
//   };

//   const handleConfirmDelete = () => {
//     if (deleteProductId) {
//       setDeleting(true);
//       deleteItem(deleteProductId).then(() => {
//         setShowModal(false);
//         setDeleteProductId(null);
//         setTimeout(() => {
//           getProducts();
//           setDeleting(false);
//         }, 3000);
//       });
//     }
//   };

//   const handleCancelDelete = () => {
//     setShowModal(false);
//     setDeleteProductId(null);
//   };

//   if (loading) {
//     return (
//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
//         {Array.from({ length: 6 }).map((_, index) => (
//           <SkeletonCard key={index} />
//         ))}
//       </div>
//     );
//   }

//   if (error) return <div>Error fetching products: {error}</div>;

//   return (
//     <div className="container mx-auto p-4">
//       {/* <h1 className="text-2xl font-bold mb-4">Products</h1> */}

//       <Button
//         className="mb-4 ml-[900px]"
//         variant="primary"
//         onClick={() => {
//           navigate("/create");
//         }}
//       >
//         Create Product
//       </Button>

//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
//         {products.map((product) => (
//           <div key={product.id} className="border rounded shadow">
//             <img
//               src={product.image}
//               alt={product.name}
//               className="mb-2 w-full h-[230px] object-cover"
//             />
//             <h2 className="font-semibold">{product.productName}</h2>
//             <p className="text-gray-600">$ {product.price}</p>
//             <div className="mt-4 mb-4">
//               <Link to={`/details/${product.id}`}>
//                 <Button className="mr-2 bg-green-500 text-white">
//                   Details
//                 </Button>
//               </Link>
//               <Button
//                 style={{ backgroundColor: "red" }}
//                 className=" text-white"
//                 onClick={() => handleDeleteClick(product.id)}
//               >
//                 Delete
//               </Button>
//             </div>
//           </div>
//         ))}
//       </div>

//       <Modal show={showModal} onHide={handleCancelDelete}>
//         <Modal.Header closeButton>
//           <Modal.Title>Confirm Deletion</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>Are you sure you want to delete this product?</Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleCancelDelete}>
//             Cancel
//           </Button>
//           <Button variant="danger" onClick={handleConfirmDelete}>
//             OK
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// };

// export default AllProducts;

import React, { useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { endPoints } from "../../apiURL/apiUrl";
import axiosInstance from "../../axiosInstance/axiosInstance";
import { useNavigate, Link } from "react-router-dom";

const SkeletonCard = () => (
  <div className="border rounded shadow p-4 animate-pulse">
    <div className="bg-gray-300 h-32 mb-2"></div>
    <div className="bg-gray-300 h-4 mb-2 w-3/4"></div>
    <div className="bg-gray-300 h-4 w-1/4"></div>
  </div>
);

const AllProducts = () => {
  const all_api = endPoints.products;
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const getProducts = async () => {
    try {
      setLoading(true);
      const res = await axiosInstance.get(all_api);
      setProducts(res.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const navigate = useNavigate();

  useEffect(() => {
    getProducts();
  }, []);


  const filteredProducts = products.filter((product) =>
    product.productName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, index) => (
          <SkeletonCard key={index} />
        ))}
      </div>
    );
  }

  if (error) return <div>Error fetching products: {error}</div>;

  return (
    <div className="container mx-auto p-4">
      <div className="flex items-center mb-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Search"
            className="border rounded-l px-2 py-1 w-32 focus:outline-none focus:ring focus:ring-blue-400"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <span
            className="absolute inset-y-0 flex items-center pl-2"
            style={{ marginLeft: "90px" }}
          >
            <svg
              className="h-4 w-4 text-gray-500"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M11 4a7 7 0 100 14 7 7 0 000-14zm3.657 10.657l4.95 4.95a1 1 0 001.415-1.415l-4.95-4.95a8 8 0 10-1.415 1.415z"
              />
            </svg>
          </span>
        </div>
      </div>
      {/* 
      <Button
        className="mb-4 ml-[900px]"
        variant="primary"
        onClick={() => {
          navigate("/create");
        }}
      >
        Create Product
      </Button> */}

      {filteredProducts.length === 0 ? (
        <div className="text-center text-gray-500">No products available</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProducts.map((product) => (
            <div key={product.id} className="border rounded shadow">
              <img
                src={product.image}
                alt={product.name}
                className="mb-2 w-full h-[230px] object-cover"
              />
              <h2 className="font-semibold">{product.productName}</h2>
              <p className="text-gray-600">$ {product.price}</p>
              <div className="mt-4 mb-4">
                <Link to={`/details/${product.id}`}>
                  <Button className="mr-2 bg-green-500 text-white">
                    Details
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AllProducts;
