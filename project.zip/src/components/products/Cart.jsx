import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Container } from "react-bootstrap";
import { FaTrash } from "react-icons/fa"; 

const Cart = () => {
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const storedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(storedCart);
    calculateTotal(storedCart);
  }, []);

  const calculateTotal = (items) => {
    const totalAmount = items.reduce((acc, item) => {
      const itemPrice = parseFloat(item.price);
      return acc + (itemPrice * item.quantity);
    }, 0);
    setTotal(totalAmount);
  };

  const handleDelete = (id) => {
    const updatedCart = cart.filter(item => item.id !== id);
    setCart(updatedCart);
    localStorage.setItem("cart", JSON.stringify(updatedCart));
    calculateTotal(updatedCart);
  };

  const handlePurchase = () => {
    alert("Purchase successful!");
    localStorage.removeItem("cart");
    setCart([]);
    setTotal(0);
    navigate("/"); 
  };

  return (
    <Container fluid className="bg-gray-100 px-4 py-8">
      <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
      {cart.length === 0 ? (
        <p className="text-gray-600">Your cart is empty.</p>
      ) : (
        <div>
          {cart.map((item) => (
            <div key={item.id} className="flex justify-between items-center bg-white p-4 rounded-md shadow mb-4">
              <div className="flex items-center">
                <img 
                  src={item.image} 
                  alt={item.productName} 
                  className="w-16 h-20 rounded-md mr-4" 
                />
                <div>
                  <h3 className="font-semibold">{item.productName}</h3>
                  <p>Quantity: {item.quantity}</p>
                  <p className="text-indigo-600">Total: ${(item.price * item.quantity).toFixed(2)}</p>
                </div>
              </div>
              <button onClick={() => handleDelete(item.id)} className="text-red-500">
                <FaTrash />
              </button>
            </div>
          ))}
          <h3 className="font-semibold">Grand Total: ${total.toFixed(2)}</h3>
          <button onClick={handlePurchase} className="bg-green-500 text-white px-4 py-2 rounded-md">
            Purchase
          </button>
        </div>
      )}
    </Container>
  );
};

export default Cart;


