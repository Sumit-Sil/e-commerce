import axios from "axios";
import React, { useEffect, useState } from "react";
import baseUrl, { endPoints } from "../../apiURL/apiUrl";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { Form, Button, Container, Row, Col } from "react-bootstrap";

function Resgister() {
  const navigate = useNavigate();
  const api = baseUrl + endPoints.register;

  // state for collected-data
  const [formData, setFormData] = useState({
    fName: "",
    lName: "",
    email: "",
    username: "",
    password: "",
  });

  // state for  database data
  const [prevData, setData] = useState([]);

  // state for error
  const [errors, setErrors] = useState({
    fName: "",
    lName: "",
    email: "",
    username: "",
    password: "",
  });

  //state for image
  const [img, setImg] = useState([]);

  useEffect(() => {
    axios
      .get(api)
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, [setData]);
  // console.log(prevData);

  let msg = "";
  const matching = prevData.find(
    (data) =>
      (msg += data.email == formData.email ? "email already exists" : "") ||
      (msg +=
        data.username == formData.username ? "username already exists" : "")
  );
  // console.log(matching);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleImage = (file) => {
    const fileReader = new FileReader();
    fileReader.readAsDataURL(file);
    fileReader.addEventListener("load", () => {
      setImg(fileReader.result);
    });
  };

  const formValue = {
    fName: formData.fName,
    lName: formData.lName,
    email: formData.email,
    username: formData.username,
    password: formData.password,
    profile_pic: img,
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let errMsg = {};

    // check for required field
    if (formData.fName == "") {
      errMsg.fName = "first name is required";
    }
    if (formData.lName == "") {
      errMsg.lName = "last name is required";
    }
    if (formData.email == "") {
      errMsg.email = "last name is required";
    }
    if (formData.username == "") {
      errMsg.username = "last name is required";
    }
    if (formData.password == "") {
      errMsg.password = "last name is required";
    } else {
      if (matching) {
        toast.error(msg, {
          position: "top-right",
          autoClose: 2000,
        });
      } else {
        axios
          .post(api, formValue)
          .then((res) => {
            console.log("axios response", res);
            toast.success("Registered Successfully", {
              position: "top-right",
              autoClose: 2000,
            });
            setTimeout(() => {
              navigate("/login");
            }, 2600);
          })
          .catch((err) => console.log(err));
      }
    }

    setErrors({ ...errors, ...errMsg });
  };

  return (
    // <section
    //   className="bg-image"
    //   style={{
    //     backgroundImage:
    //       'url("https://plus.unsplash.com/premium_vector-1682305378650-373ea23d6d85?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fG1lbiUyMGNsb3RoaW5nfGVufDB8fDB8fHww")',
    //     height: "1000px",
    //   }}
    // >
    //   <div className="mask d-flex align-items-center gradient-custom-3">
    //     <div className="container h-100 mt-2">
    //       <div className="row d-flex justify-content-center align-items-center h-100">
    //         <div className="col-12 col-md-9 col-lg-7 col-xl-6">
    //           <div
    //             className="card"
    //             style={{
    //               border: "1px solid black",
    //               borderRadius: 15,
    //               background: "",
    //             }}
    //           >
    //             <div className="card-body p-5">
    //               <h2 className="text-uppercase text-center mb-5">
    //                 Create an account
    //               </h2>
    //               <form onSubmit={handleSubmit}>
    //                 <div className="form-outline mb-2 text-start ">
    //                   <label className="form-label" htmlFor="form3Example1cg">
    //                     First Name
    //                   </label>
    //                   <input
    //                     type="text"
    //                     className="form-control form-control-lg"
    //                     name="fName"
    //                     onChange={handleChange}
    //                     style={{ border: "0.5px solid black" }}
    //                   />
    //                   {errors && errors.fName ? (
    //                     <p className="text-danger">{errors.fName}</p>
    //                   ) : (
    //                     ""
    //                   )}
    //                 </div>
    //                 <div className="form-outline mb-4 text-start">
    //                   <label className="form-label" htmlFor="form3Example3cg">
    //                     Last Name
    //                   </label>
    //                   <input
    //                     type="text"
    //                     className="form-control form-control-lg"
    //                     name="lName"
    //                     onChange={handleChange}
    //                     style={{ border: "0.5px solid black" }}
    //                   />
    //                   {errors && errors.lName ? (
    //                     <p className="text-danger">{errors.lName}</p>
    //                   ) : (
    //                     ""
    //                   )}
    //                 </div>
    //                 <div
    //                   data-mdb-input-init=""
    //                   className="form-outline mb-4 text-start"
    //                 >
    //                   <label className="form-label" htmlFor="form3Example3cg">
    //                     Your Email
    //                   </label>
    //                   <input
    //                     type="email"
    //                     id="form3Example3cg"
    //                     className="form-control form-control-lg"
    //                     name="email"
    //                     onChange={handleChange}
    //                     style={{ border: "0.5px solid black" }}
    //                   />
    //                   {errors && errors.email ? (
    //                     <p className="text-danger">{errors.email}</p>
    //                   ) : (
    //                     ""
    //                   )}
    //                 </div>
    //                 <div
    //                   data-mdb-input-init=""
    //                   className="form-outline mb-4 text-start"
    //                 >
    //                   <label className="form-label" htmlFor="form3Example4cg">
    //                     Username
    //                   </label>
    //                   <input
    //                     type="text"
    //                     id="form3Example4cg"
    //                     className="form-control form-control-lg"
    //                     name="username"
    //                     onChange={handleChange}
    //                     style={{ border: "0.5px solid black" }}
    //                   />
    //                   {errors && errors.username ? (
    //                     <p className="text-danger">{errors.username}</p>
    //                   ) : (
    //                     ""
    //                   )}
    //                 </div>
    //                 <div
    //                   data-mdb-input-init=""
    //                   className="form-outline mb-4 text-start"
    //                 >
    //                   <label className="form-label" htmlFor="form3Example4cdg">
    //                     Password
    //                   </label>
    //                   <input
    //                     type="password"
    //                     id="form3Example4cdg"
    //                     className="form-control form-control-lg"
    //                     name="password"
    //                     onChange={handleChange}
    //                     style={{ border: "0.5px solid black" }}
    //                   />
    //                   {errors && errors.password ? (
    //                     <p className="text-danger">{errors.password}</p>
    //                   ) : (
    //                     ""
    //                   )}
    //                 </div>
    //                 <div className="form-outline mb-4 text-start">
    //                   <label className="form-label " htmlFor="form3Example1cg">
    //                     Profile Pic
    //                   </label>
    //                   <input
    //                     type="file"
    //                     className="form-control form-control-lg"
    //                     name="image"
    //                     onChange={(e) => {
    //                       handleImage(e.target.files[0]);
    //                     }}
    //                     style={{ border: "0.5px solid black" }}
    //                   />
    //                   {errors && errors.fName ? (
    //                     <p className="text-danger">{errors.fName}</p>
    //                   ) : (
    //                     ""
    //                   )}
    //                 </div>
    //                 <div className="d-flex justify-content-center">
    //                   <button
    //                     type="submit"
    //                     value="submit"
    //                     data-mdb-button-init=""
    //                     data-mdb-ripple-init=""
    //                     className="btn btn-success btn-block btn-lg gradient-custom-4 text-body"
    //                   >
    //                     Register
    //                   </button>
    //                 </div>
    //                 <p className="text-center text-muted mt-5 mb-0">
    //                   Have already an account?{" "}
    //                   <a href="/login" className="fw-bold text-body">
    //                     <u>Login here</u>
    //                   </a>
    //                 </p>
    //               </form>
    //             </div>
    //           </div>
    //         </div>
    //       </div>
    //     </div>
    //   </div>
    // </section>
        <div style={{ 
      backgroundImage: "url('https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')",
      backgroundSize: "cover",
      backgroundPosition: "center",
      backgroundRepeat: "no-repeat",
      // height: "100vh",
      height:"700px"
    }}>
      <Container className="d-flex align-items-center justify-content-center h-100">
        <div style={{ marginTop: "50px", width: "100%" }}>
          <Row className="justify-content-md-center">
            <Col xs={12} md={6} lg={4} style={{ 
              backgroundColor: "rgba(254, 243, 199, 0.9)", 
              border: "1px solid black", 
              borderRadius: "10px",
              padding: "10px",
              width:"400px"
            }}>
              <h2 className="text-center mb-4 mt-3">Register</h2>
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3 text-start" controlId="formBasicFullName">
                  <Form.Label><b>Full Name</b></Form.Label>
                  <Form.Control type="text" name="fullName" placeholder="Full Name" onChange={handleChange} />
                  {errors.fullName && <p className="text-danger">{errors.fullName}</p>}
                </Form.Group>

                <Form.Group className="mb-3 text-start" controlId="formBasicEmail">
                  <Form.Label><b>Email</b></Form.Label>
                  <Form.Control type="email" name="email" placeholder="Email" onChange={handleChange} />
                  {errors.email && <p className="text-danger">{errors.email}</p>}
                </Form.Group>

                <Form.Group className="mb-3 text-start" controlId="formBasicUsername">
                  <Form.Label><b>Username</b></Form.Label>
                  <Form.Control type="text" name="username" placeholder="Username" onChange={handleChange} />
                  {errors.username && <p className="text-danger">{errors.username}</p>}
                </Form.Group>

                <Form.Group className="mb-3 text-start" controlId="formBasicPassword">
                  <Form.Label><b>Password</b></Form.Label>
                  <Form.Control type="password" name="password" placeholder="Password" onChange={handleChange} />
                  {errors.password && <p className="text-danger">{errors.password}</p>}
                </Form.Group>

                <Form.Group className="mb-3 text-start" controlId="formBasicProfilePic">
                  <Form.Label><b>Profile Picture</b></Form.Label>
                  <Form.Control type="file" name="profilePic" onChange={handleChange} />
                </Form.Group>

                <Button variant="primary" type="submit" className="w-100">
                  Register
                </Button>
              </Form>
              <p className="text-center mt-4">
                Already have an account? <Link to="/login" className="text-blue-500 hover:underline">Log in</Link>
              </p>
            </Col>
          </Row>
        </div>
      </Container>
    </div>

  );
}

export default Resgister;
