import './App.css';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Routing from './routing/Routing';
import ClassComponent from './ClassComponent';

function App() {
  return (
    <div className="App">
  <Routing/>
   <ToastContainer/>
   {/* <ClassComponent/> */}
    </div>
  );
}

export default App;
