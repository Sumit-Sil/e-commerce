import React from "react";
import { AiOutlineUser } from "react-icons/ai";
import { FiShoppingCart } from "react-icons/fi";
import { Link } from "react-router-dom";
import { NavLink } from "react-router-dom";


function Header() {
  let uid = window.localStorage.getItem("uid");
  let id = window.localStorage.getItem("id");
  return !uid ? (
    <div className="bg-yellow-400 shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between h-[60px] p-2.5">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold ml-3">Clothy</h1>
        </div>

        <div className="hidden md:flex space-x-8">
          <a href="/" className="text-gray-700 hover:text-blue-500">
            Home
          </a>
          <a href="#" className="text-gray-700 hover:text-blue-500">
            About
          </a>
          <a href="/all" className="text-gray-700 hover:text-blue-500">
            Products
          </a>
        </div>

        <div className="flex items-center space-x-4">
          <Link to={"/login"}>
            <AiOutlineUser style={{ fontSize: "30px" }} />
          </Link>
          <FiShoppingCart
            style={{ fontSize: "26px", margin: "0px 13px" }}
            onClick={() => {
              alert("Please log in first");
            }}
          />
        </div>

        <div className="md:hidden">
          <button className="focus:outline-none">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16m-7 6h7"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  ) : (
    <div className="bg-yellow-400 shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between h-[60px] p-2.5">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold ml-3">Clothy</h1>
        </div>

        <div className="hidden md:flex space-x-8">
          <NavLink to="/" className="text-gray-700 hover:text-blue-500">
            Home
          </NavLink>
          <a href="#" className="text-gray-700 hover:text-blue-500">
            About
          </a>
          <NavLink to="/all" className="text-gray-700 hover:text-blue-500">
          Products
          </NavLink>
          <a href="/all">
            
          </a>
        </div>

        <div className="flex items-center space-x-4">
          <Link to={`/profile/${id}`}>
            <img
              src="https://plus.unsplash.com/premium_photo-1663051023354-0a8309995d87?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" // Replace with your profile picture URL
              alt="Profile"
              className="w-10 h-10 rounded-full border border-gray-300"
            />
          </Link>
          <Link to={`/cart`}>
            <FiShoppingCart style={{ fontSize: "26px", margin: "0px 13px" }} />
          </Link>
        </div>

        <div className="md:hidden">
          <button className="focus:outline-none">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16m-7 6h7"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}

export default Header;
