const baseUrl="http://localhost:4000/"
export const endPoints={
    register:"registration",
    products:"products"
}
export default baseUrl