import React from 'react'

const Footer = () => {
  return (
<section className="footer">
  <div className="footer-row">
    <div className="footer-col">
      <h4 className='text-start'>About Clothy</h4>
      <p className='text-start'>Lorem ipsum Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed tempora repudiandae quisquam temporibus minima porro vitae sunt similique animi aperiam!dolor sit, amet consectetur adipisicing elit. Asperiores sunt similique in amet dicta nesciunt dolor sed optio nulla eius!</p>
      {/* <ul className="links">
        <li>
          <a href="#">About Clothy</a>
        </li>
        <li>
          <a href="#">Compressions</a>
        </li>
        <li>
          <a href="#">Customers</a>
        </li>
        <li>
          <a href="#">Service</a>
        </li>
        <li>
          <a href="#">Collection</a>
        </li>
      </ul> */}
    </div>
    <div className="footer-col">
      <h4>Quick Links</h4>
      <ul className="links text-start">
        <li>
          <a href="#">Home</a>
        </li>
        <li>
          <a href="#">About</a>
        </li>
        <li>
          <a href="#">Contact</a>
        </li>
        <li>
          <a href="#">Popular Designs</a>
        </li>
        <li>
          <a href="#">Artistic</a>
        </li>
        <li>
          <a href="#">New Products</a>
        </li>
      </ul>
    </div>
    <div className="footer-col">
      <h4 style={{marginRight:"65px"}}>Legal</h4>
      <ul className="links text-start">
        <li>
          <a href="#">Customer Agreement</a>
        </li>
        <li>
          <a href="#">Privacy Policy</a>
        </li>
        <li>
          <a href="#">GDPR</a>
        </li>
        <li>
          <a href="#">Security</a>
        </li>
        <li>
          <a href="#">Testimonials</a>
        </li>
        <li>
          <a href="#">Media Kit</a>
        </li>
      </ul>
    </div>
    <div className="footer-col">
      <h4>Newsletter</h4>
      <p>
        Subscribe to our newsletter for a weekly dose of news, updates, helpful
        tips, and exclusive offers.
      </p>
      <form action="#">
        <input type="text" placeholder="Your email" required="" />
        <button type="submit">SUBSCRIBE</button>
      </form>
      <div className="icons" style={{fontSize:"20px",marginLeft:"5px"}}>
        <i className="fa-brands fa-facebook-f" />
        <i className="fa-brands fa-twitter" />
        <i className="fa-brands fa-linkedin" />
        <i className="fa-brands fa-github" />
      </div>
    </div>
  </div>
</section>

  )
}

export default Footer
