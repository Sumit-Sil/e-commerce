import React from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Button, Image } from "react-bootstrap";
import { AiOutlineUser } from "react-icons/ai";
import { FiShoppingCart } from "react-icons/fi";
import { Link } from "react-router-dom";

function Header() {
  let uid = window.localStorage.getItem("uid");
  let id = window.localStorage.getItem("id");
  return !uid ? (
    <nav
      className="flex items-center justify-between h-[60px] p-2.5 bg-yellow-400 shadow-md"
      style={{ position: "sticky" }}
    >
      <div className="flex items-center">
        <h1 className="text-2xl font-bold ml-3">Clothy</h1>
      </div>

      <div className="hidden md:flex space-x-8">
        <a href="/" className="text-gray-700 hover:text-blue-500">
          Home
        </a>
        <a href="#" className="text-gray-700 hover:text-blue-500">
          About
        </a>
        <a href="/all" className="text-gray-700 hover:text-blue-500">
          Products
        </a>
      </div>

      <div className="flex items-center space-x-4">
        {/* <button className="px-4 py-2 text-white bg-blue-600 rounded hover:bg-blue-700">Log In</button> */}
        {/* <button className="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700">Sign Up</button> */}
        <a href="/login">
          <AiOutlineUser style={{ fontSize: "30px" }} />
        </a>
        <FiShoppingCart style={{ fontSize: "26px", margin: "0px 13px" }} />
        {/* <img
    src="https://plus.unsplash.com/premium_photo-1663051023354-0a8309995d87?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" // Replace with your profile picture URL
    alt="Profile"
    className="w-10 h-10 rounded-full border border-gray-300"
  /> */}
      </div>

      <div className="md:hidden">
        {/* Mobile menu button */}
        <button className="focus:outline-none">
          <svg
            xmlns="https://plus.unsplash.com/premium_photo-1663051023354-0a8309995d87?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 6h16M4 12h16m-7 6h7"
            />
          </svg>
        </button>
      </div>
    </nav>
  ) : (
    <div>
      <nav
        className="flex items-center justify-between h-[70px] p-2.5 bg-yellow-400 shadow-md"
        style={{ position: "sticky" }}
      >
        <div className="flex items-center">
          <h1 className="text-2xl font-bold ml-3">Clothy</h1>
        </div>

        <div className="hidden md:flex space-x-8">
          <a href="/" className="text-gray-700 hover:text-blue-500">
            Home
          </a>
          <a href="#" className="text-gray-700 hover:text-blue-500">
            About
          </a>
          <a href="/all" className="text-gray-700 hover:text-blue-500">
            Products
          </a>
        </div>

        <div className="flex items-center space-x-4">
          {/* <a href={`/profile/${id}`}><AiOutlineUser style={{fontSize:"30px"}}/></a> */}
          <Link to={`/profile/${id}`}>
            <img
              src="https://plus.unsplash.com/premium_photo-1663051023354-0a8309995d87?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" // Replace with your profile picture URL
              alt="Profile"
              className="w-10 h-10 rounded-full border border-gray-300"
            />
          </Link>
          <FiShoppingCart style={{ fontSize: "26px", margin: "0px 13px" }} />
        </div>

        <div className="md:hidden">
          <button className="focus:outline-none">
            <svg
              xmlns="https://plus.unsplash.com/premium_photo-1663051023354-0a8309995d87?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16m-7 6h7"
              />
            </svg>
          </button>
        </div>
      </nav>
    </div>
  );
}

export default Header;
