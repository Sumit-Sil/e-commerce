import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Card from "react-bootstrap/Card";
import baseUrl, { endPoints } from "../../apiURL/apiUrl";

function Profile() {
  const { id } = useParams();
  const api = baseUrl+endPoints.register + "/" + id;

  const [userData, setData] = useState([]);
  useEffect(() => {
    axios
      .get(api)
      .then((res) => setData(res.data))
      .catch((err) => err);
  }, [setData]);
  console.log(userData);
  const { fName, lName, username, email } = userData;
  return (
    <Card
      style={{
        width: "18rem",
        display: "inline-block",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 20,
      }}
    >
      <Card.Img
        variant="top"
        src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png"
      />
      <Card.Body>
        <Card.Title>
          {fName} {lName}
        </Card.Title>
        <Card.Text>{username}</Card.Text>
        <Card.Text>{email}</Card.Text>
      </Card.Body>
    </Card>
  );
}

export default Profile;
