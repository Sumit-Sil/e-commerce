import axios from "axios";
import React, { useEffect, useState } from "react";
import baseUrl, { endPoints } from "../../apiURL/apiUrl";
import { useNavigate } from "react-router-dom";
import { Form, Button, Container, Row, Col } from "react-bootstrap";
import { toast } from "react-toastify";

function LogIn() {
  const navigate = useNavigate();
  const api = baseUrl + endPoints.register;

  // state for collected-data
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  //state for error handling
  const [errors, setErrors] = useState({
    email: "",
    password: "",
  });

  // state for  database data
  const [PrevData, setData] = useState([]);

  useEffect(() => {
    axios
      .get(api)
      .then((res) => {
        console.log(res.data);
        setData(res.data);
      })
      .catch((err) => console.log("login error", err));
  }, [setData]);

  // check for existing data
  const match = PrevData.find(
    (data) => data.email == formData.email || data.username == formData.email
  );

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    
    // checking if all fields are filled or not
    if (formData.email == "" && formData.password) {
      setErrors({ email: "email is required", password: "" });
    } else if (formData.email && formData.password == "") {
      setErrors({ email: "", password: "password is required" });
    } else if (formData.email == "" && formData.password == "") {
      setErrors({
        email: "email is required",
        password: "password is required",
      });
    }
    // ckecking password and username
    else {
      if (match) {
        if (match.password == formData.password) {
          toast.success("Log in Successfull", {
            position: "top-right",
            autoClose: 2000,
          });
          setTimeout(() => {
            navigate(`/profile/${match.id}`);
          }, 2600);
        } else {
          setErrors({ email: "", password: "password is incorrect" });
        }
      } else {
        toast.error("Invalid Credentials");
        setErrors({ email: "Invalid email username", password: "" });
      }
    }
  };

  // console.log(formData);
  // console.log(errors);

  return (
    <Container>
      <Row className="justify-content-md-center mt-5">
        <Col xs={12} md={6}>
          <h2 className="text-center mb-4">Login</h2>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3 text-start" controlId="formBasicEmail">
              <Form.Label>Email address or Username</Form.Label>
              <Form.Control
                type="text"
                name="email"
                placeholder="Enter email"
                onChange={handleChange}
              />
              {errors && errors.email ? (
                <p className="text-danger">{errors.email}</p>
              ) : (
                ""
              )}
            </Form.Group>

            <Form.Group
              className="mb-3 text-start"
              controlId="formBasicPassword"
            >
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Password"
                name="password"
                onChange={handleChange}
              />
              {errors && errors.password ? (
                <p className="text-danger">{errors.password}</p>
              ) : (
                ""
              )}
            </Form.Group>

            <Button variant="primary" type="submit" className="w-100">
              Login
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default LogIn;
