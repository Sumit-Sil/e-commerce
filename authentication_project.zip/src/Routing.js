import React from 'react'
import { Route,Routes,BrowserRouter as Router } from 'react-router-dom'
import Header from './layout/Header'
import Resgister from './components/authentication/Resgister'
import LogIn from './components/authentication/LogIn'
import Profile from './components/authentication/Profile'
import Home from './components/Home'

function Routing() {
  return (
    <div>
      <Router>
        <Header/>
        <Routes>
            <Route path='/home' element={<Home/>}/>
            <Route path='/' element={<Resgister/>}/>
            <Route path='/login' element={<LogIn/>}/>
            <Route path="/profile/:id" element={<Profile/>}/>
        </Routes>
      </Router>
    </div>
  )
}

export default Routing
