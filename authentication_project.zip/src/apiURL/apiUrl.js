const baseUrl="http://localhost:4000/"
export const endPoints={
    register:"registration",
    login :"login"
}
export default baseUrl